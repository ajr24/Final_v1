package com.afkl.exercises.spring.fares;

public enum Currency {

    EUR, USD

}
