package com.afkl.exercises.spring.locations;

import lombok.Value;

@Value
public class Coordinates {

    private double latitude, longitude;

}
